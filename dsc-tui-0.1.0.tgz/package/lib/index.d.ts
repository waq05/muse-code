/**
 * dsc-tui — DeepSeek Harness 的个人终端前端。
 *
 * cordis 插件四件套：name / inject / Config / apply（写法对齐官方
 * dsh-acp 桥）。Loader 从 profile 目录按 `name: 'dsc-tui'` 导入本模块。
 *
 * 分层：本文件只做装配（配置透传 + ink render + disposer）；
 * 宿主交互全部收在 src/adapter/**，UI 只消费 src/contract.ts 的中立类型。
 */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
export declare const name = "dsc-tui";
/** 启动顺序保障：这些服务由 dsh-base 提供，本插件消费。 */
export declare const inject: string[];
/** 插件配置（cordis.patch.yml 的 dsc-tui 行传入）。 */
export interface DscConfig {
    /** LLM 提供方路由；缺省走 agent-default-model（deepseek-official/deepseek-flash）。 */
    provider?: string;
    /** 模型名；缺省走 agent-default-model。 */
    model?: string;
    /** 推理强度：off/low/high/max；缺省为 adapter 默认。 */
    effort?: string;
    /** 启动即恢复的会话 id（dsc --resume 经 DSC_RESUME_SESSION 传入）。 */
    resumeSessionId?: string;
}
export declare const Config: Schema<Schemastery.ObjectS<{
    provider: Schema<string, string>;
    model: Schema<string, string>;
    effort: Schema<string, string>;
    resumeSessionId: Schema<string, string>;
}>, Schemastery.ObjectT<{
    provider: Schema<string, string>;
    model: Schema<string, string>;
    effort: Schema<string, string>;
    resumeSessionId: Schema<string, string>;
}>>;
/**
 * 挂载 TUI。cordis 约定：apply 返回函数 = fiber 卸载时执行的 disposer
 * （cordis/lib/index.js 的 runner.collect(effect)），用它卸载 ink 并释放 agent。
 */
export declare function apply(ctx: Context, config: DscConfig): () => void;
