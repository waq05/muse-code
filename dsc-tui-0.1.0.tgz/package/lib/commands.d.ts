/**
 * 斜杠命令解析与派发（只消费 DscRuntime 契约，不碰宿主）。
 * @module dsc-tui/commands
 */
import type { DscRuntime } from './contract.js';
/** UI 侧需要的回调：打开会话选择器、显示一次性提示行。 */
export interface CommandContext {
    openPicker(): void;
    notice(text: string): void;
}
export declare const HELP_TEXT: string;
/**
 * 执行一条 `/...` 命令；参数错误经 notice 反馈，不产生 system 条目。
 * @returns 输入是否为命令（false = 普通消息）。
 */
export declare function runCommand(input: string, runtime: DscRuntime, ui: CommandContext): boolean;
