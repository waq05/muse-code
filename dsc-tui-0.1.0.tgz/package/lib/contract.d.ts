/**
 * UI ⇄ adapter 的共享契约（单一真源）。
 *
 * 边界规则（对齐 dsh-TUI 的 adapter 边界实践）：
 *   - `src/adapter/**` 是唯一允许 import `@deepseek-ai/*` 运行期包的层；
 *   - UI 层（src/app/**、src/state/**、src/commands.ts）只依赖本文件的
 *     中立类型，通过 DscRuntime 与宿主世界交互；
 *   - 本文件自身不得 import 任何 @deepseek-ai/*。
 */
/** deepseek adapter 的推理强度档位。 */
export type EffortLevel = 'off' | 'low' | 'high' | 'max';
/** 一次工具调用的展示状态。 */
export type ToolStatus = 'running' | 'done' | 'failed' | 'rejected';
/** 工具卡片视图：参数原文 +（完成后的）结果摘要。 */
export interface ToolCallView {
    callId: string;
    name: string;
    /** 模型产出的原始 arguments JSON 字符串（截断由 UI 决定）。 */
    argsText: string;
    /** 工具结果文本（可能为空：无结果或尚未完成）。 */
    resultText?: string;
    status: ToolStatus;
}
/**
 * 会话流里的一条可渲染条目。adapter 把 session/event 折叠成这个序列，
 * UI 只读消费；`id` 单调递增、仅在本会话生命周期内唯一。
 */
export type TranscriptEntry = {
    kind: 'user';
    id: number;
    text: string;
} | {
    kind: 'thinking';
    id: number;
    text: string;
} | {
    kind: 'text';
    id: number;
    text: string;
} | {
    kind: 'tool';
    id: number;
    call: ToolCallView;
} | {
    kind: 'system';
    id: number;
    text: string;
};
/** 会话累计 token 用量。 */
export interface TokenUsageView {
    inputTokens: number;
    outputTokens: number;
}
/** 底部状态行数据。 */
export interface StatusView {
    sessionId: string | null;
    /** 当前模型名；未知时 'unknown'。 */
    model: string;
    effort: EffortLevel | null;
    turnState: 'idle' | 'thinking' | 'working' | 'awaiting-approval';
    usage: TokenUsageView | null;
}
/** 待用户决定的工具审批请求（视图投影）。 */
export interface ApprovalRequestView {
    /** adapter 内部关联 id；answerApproval 不需要它（同一时刻至多一个挂起审批）。 */
    id: string;
    toolName: string;
    /** 参数摘要（单行、已截断）。 */
    argsSummary: string;
}
/** 审批应答。v1 只提供一次性决定（对齐官方 ACP 桥的 one-shot 语义）。 */
export type ApprovalAnswer = 'allow-once' | 'reject';
/** /resume 会话选择器的一行。 */
export interface SessionSummary {
    id: string;
    cwd: string;
    createdAt: number;
    /** 会话标题（session-title / session/title 事件投影），未知时 undefined。 */
    title?: string;
}
/** UI 每帧读取的运行时快照（useSyncExternalStore 的 getSnapshot 返回）。 */
export interface RuntimeSnapshot {
    entries: TranscriptEntry[];
    status: StatusView;
    /** 同一时刻至多一个挂起审批；null = 无。 */
    pendingApproval: ApprovalRequestView | null;
    /** refreshSessions() 填充的会话列表缓存。 */
    sessions: SessionSummary[];
    sessionsLoading: boolean;
}
/**
 * adapter 实现、UI 消费的唯一运行期接口。
 *
 * 约定：
 *   - subscribe/getSnapshot 遵循 useSyncExternalStore 语义（快照引用在两次
 *     notify 之间稳定）；
 *   - 所有方法不得抛出未捕获异常到 UI；失败经 entries 追加 kind:'system'
 *     条目报告；
 *   - openSession(undefined) 新建会话并切换；openSession(id) 恢复之；
 *     切换时清空 entries。
 */
export interface DscRuntime {
    subscribe(listener: () => void): () => void;
    getSnapshot(): RuntimeSnapshot;
    /** 提交一条用户消息（走 agent.followup）。 */
    submit(text: string): void;
    /** 尝试取消当前回合（M4 前可为 no-op + system 提示）。 */
    interrupt(): void;
    openSession(id?: string): Promise<void>;
    compact(): Promise<void>;
    setModel(model: string): Promise<void>;
    setEffort(effort: EffortLevel): Promise<void>;
    /** 异步刷新 sessions 列表（结果写回快照的 sessions/sessionsLoading）。 */
    refreshSessions(): Promise<void>;
    answerApproval(answer: ApprovalAnswer): void;
    /** 退出应用（dispose → 进程结束）。 */
    exit(): void;
    /** 释放全部资源（dispose agent、退订）；集成层在 ink unmount 后调用。 */
    dispose(): void;
}
