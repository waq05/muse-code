/**
 * 宿主访问的唯一边界层（类型面）。
 *
 * 边界规则：只有 `src/adapter/**` 允许 import '@deepseek-ai/*'（运行时值 import
 * 也只出现在这里）；UI 层（src/app/**、src/commands.ts）只消费 `../contract.js`
 * 的中性类型。宿主升级时只需要改本目录。
 *
 * 解析说明：插件安装在 profile 目录里，bare 的 '@deepseek-ai/*' import 会被解析到
 * dsh 宿主自带的同一份实现（单实例，已实测 import.meta.resolve）；package.json
 * 里的 optional peers 是便携性兜底。
 *
 * @module dsc-tui/adapter/host
 */
export type { Context } from '@deepseek-ai/cordis';
export type { Agent, AgentHandle, AgentOptions, AgentStatus, AssistantStreamFrame, } from '@deepseek-ai/dsh-agent';
export type { Session, SessionEvent, SessionId, UserMessage } from '@deepseek-ai/dsh-session';
export type { SessionPersistenceSnapshot } from '@deepseek-ai/dsh-session-persistence';
export type { ApprovalOutcome } from '@deepseek-ai/dsh-user-approval';
