/**
 * 会话日志 → 中性 transcript 的折叠器（无 React、无宿主值 import）。
 *
 * 数据来源分工：
 * - 持久事件（`session/event` 的 `event.data`）是唯一真相：user 回显、定稿的
 *   文本/思考（`assistant/message`）、工具卡（`tool/call` ↔ `tool/result` 按
 *   callId 配对）、usage、compaction 标记。
 * - 直播尾（`agent/assistant-stream` 的 chunk 帧）只维护 `liveSegments`，
 *   供快照拼在定稿条目之后；`assistant/message` 一到就清空，避免重复渲染。
 *
 * @module dsc-tui/adapter/transcript
 */
import type { AssistantStreamFrame, SessionEvent } from './host.js';
import type { TokenUsageView, TranscriptEntry } from '../contract.js';
declare const errText: (error: unknown) => string;
/** 把会话事件流折叠成有序 transcript（条目对象一旦发布视为不可变，更新靠替换）。 */
export declare class Transcript {
    /** 定稿条目（append-only；`clear()` 重置）。 */
    private list;
    /** callId → 工具条目在 `list` 中的下标（append-only 保证下标稳定）。 */
    private toolIndex;
    private seq;
    /** 直播尾段（`assistant/message`/`turn/end`/清空时重置）。 */
    private segments;
    /** 本会话累计 token 用量。 */
    usage: TokenUsageView;
    /** 当前是否有打开的 step（驱动 working/thinking 状态区分）。 */
    stepOpen: boolean;
    /** 定稿条目的只读视图。 */
    get entries(): readonly TranscriptEntry[];
    /** 直播尾条目（负 id，与定稿的正 id 不冲突）。 */
    liveEntries(): TranscriptEntry[];
    /** 追加一条系统提示（错误/状态说明）。 */
    system(text: string): void;
    /** 清空（开新会话/恢复会话时）。 */
    clear(): void;
    /**
     * 折叠一条持久会话事件。
     * @returns 是否产生了可见变化（调用方据此决定是否通知 UI）。
     */
    reduce(event: SessionEvent): boolean;
    /**
     * 应用一帧 `agent/assistant-stream`（start/chunk/end）。
     * @returns 是否产生了可见变化。
     */
    applyFrame(frame: AssistantStreamFrame): boolean;
    /** 追加到同类型尾段，否则开新段。 */
    private appendSegment;
    /** 定稿文本：合并进相邻的最后一个 text 条目。 */
    private pushAssistantText;
    /** 定稿思考：合并进相邻的最后一个 thinking 条目（折叠展示）。 */
    private pushThinking;
}
export { errText };
