import type { Context } from './host.js';
import type { DscRuntime } from '../contract.js';
/** 插件配置里 adapter 关心的字段（由 index.ts 透传，避免与 index 循环 import）。 */
export interface DscRuntimeConfig {
    provider?: string | undefined;
    model?: string | undefined;
    /** 'off' | 'low' | 'high' | 'max'（deepseek adapter 档位）；非法值忽略。 */
    effort?: string | undefined;
    resumeSessionId?: string | undefined;
}
/**
 * 创建 TUI 运行时。构造即发起：打开初始会话 + 拉取会话列表（均异步落快照）。
 * 监听全部经 `ctx.on`（fiber 作用域），插件卸载时自动退订。
 */
export declare function createRuntime(ctx: Context, config: DscRuntimeConfig): DscRuntime;
