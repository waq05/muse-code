import type { JSX } from 'react';
export interface ComposerProps {
    disabled: boolean;
    placeholder: string;
    onSubmit: (text: string) => void;
}
export declare function Composer({ disabled, placeholder, onSubmit }: ComposerProps): JSX.Element;
