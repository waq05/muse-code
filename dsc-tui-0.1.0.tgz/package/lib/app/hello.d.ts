import type { DscConfig } from '../index.js';
interface ServicePresence {
    agents: boolean;
    llm: boolean;
    sessionPersistence: boolean;
}
export declare function Hello(props: {
    config: DscConfig;
    services: ServicePresence;
}): import("react").JSX.Element;
export {};
