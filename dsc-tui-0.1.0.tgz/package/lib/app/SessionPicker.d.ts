import type { JSX } from 'react';
import type { SessionSummary } from '../contract.js';
/** 键盘路由（↑↓/Enter/Esc）在 App 顶层统一处理，本组件纯展示。 */
export interface SessionPickerProps {
    sessions: SessionSummary[];
    loading: boolean;
    index: number;
    onIndex: (index: number) => void;
}
export declare function SessionPicker({ sessions, loading, index, onIndex }: SessionPickerProps): JSX.Element;
