import type { JSX } from 'react';
import type { StatusView } from '../contract.js';
export declare function StatusBar({ status }: {
    status: StatusView;
}): JSX.Element;
