import type { JSX } from 'react';
import type { TranscriptEntry } from '../contract.js';
export declare function ChatView({ entries, turnState, expandThinking, }: {
    entries: TranscriptEntry[];
    turnState: 'idle' | 'thinking' | 'working' | 'awaiting-approval';
    expandThinking: boolean;
}): JSX.Element;
