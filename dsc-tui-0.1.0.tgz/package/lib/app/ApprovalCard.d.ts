import type { JSX } from 'react';
import type { ApprovalRequestView } from '../contract.js';
export declare function ApprovalCard({ request }: {
    request: ApprovalRequestView;
}): JSX.Element;
