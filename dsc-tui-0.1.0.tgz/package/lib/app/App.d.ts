import type { JSX } from 'react';
import type { DscRuntime } from '../contract.js';
export declare function App({ runtime }: {
    runtime: DscRuntime;
}): JSX.Element;
