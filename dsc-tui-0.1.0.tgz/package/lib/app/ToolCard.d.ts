import type { JSX } from 'react';
import type { ToolCallView } from '../contract.js';
export declare function ToolCard({ call }: {
    call: ToolCallView;
}): JSX.Element;
